import urllib.request
import json
import codecs
import os
from bug_classes import Bug, Bugs, History, Change, Comment


def history(id):
    with urllib.request.urlopen('https://bugzilla.mozilla.org/rest/bug/' + str(id) + '/history') as response:
        json1 = response.read()
        json2 = json1.decode("utf-8")
        json3 = json.loads(json2)
    with open('history_' + str(id) + '.txt', 'w') as f:
        json.dump(json3, f)
    return


def comment(id):
    with urllib.request.urlopen('https://bugzilla.mozilla.org/rest/bug/' + str(id) + '/comment') as response:
        
        json1 = response.read()
        json2 = json1.decode("utf-8")
        json3 = json.loads(json2)
    with open('comment_' + str(id) + '.txt', 'w') as f:
        json.dump(json3, f)
    return


def buildBugObjects():
    directory = ''
    main_bug_file = 'main_bug_file.txt'
    history_prefix = 'history_'
    comment_prefix = 'comment_'

    # create collection of bugs
    allBugs = Bugs()

    # open main JSON file containing all bugs
    with open('main_bug_file.txt', 'r', encoding="utf8") as f:
        read_data = f.read()
        print(read_data)
        print(type(read_data))
        json_dict = json.loads(read_data)

    # get string name all the members of the classes
    members = [attr for attr in dir(Bug()) if not callable(attr) and not attr.startswith("__")]
    comment_members = [attr for attr in dir(Comment()) if not callable(attr) and not attr.startswith("__")]
    history_members = [attr for attr in dir(History()) if not callable(attr) and not attr.startswith("__")]
    change_members = [attr for attr in dir(Change()) if not callable(attr) and not attr.startswith("__")]

    # loop over all the bugs
    for curr_bug_dict in json_dict['bugs']:
        curr_bug = Bug()
        # loop over all member names and determine if populated if so set
        for member in members:
            if member in curr_bug_dict.keys():
                setattr(curr_bug, member, curr_bug_dict[member])

        # if we could not set the bug id there is a problem and we should not add bug to collection
        curr_bug_id = curr_bug.id
        history(curr_bug_id)
        comment(curr_bug_id)
    return


def DownloadAllBug():
    with urllib.request.urlopen('https://bugzilla.mozilla.org/rest/bug?product=Firefox&creation_time=2016-10-1T13:50:04Z') as response:
        json1 = response.read()
        json2 = json1.decode("utf-8")
        json3 = json.loads(json2)
    with open('main_bug_file.txt', 'w') as f:
        json.dump(json3, f)
    return

DownloadAllBug()
buildBugObjects()
